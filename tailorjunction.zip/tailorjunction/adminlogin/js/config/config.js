/**
 * @file config.js
 * @author Sanjay Sunil
 * @license MIT
 */

const firebaseConfig = {
  apiKey: "AIzaSyC_pIZWNXaieFgV80QPhh6b1ylcjpTAQUI",
  authDomain: "tailor-421019.firebaseapp.com",
  projectId: "tailor-421019",
  storageBucket: "tailor-421019.appspot.com",
  messagingSenderId: "61589354002",
  appId: "1:61589354002:web:15b976ea0367948cf10acb",
  measurementId: "G-5ZPCFLWY2J"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);